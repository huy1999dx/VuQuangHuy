import 'package:flutter/material.dart';
import 'MyApp.dart';
void main(){
  //Center is a widget, Text is a widget
  runApp(
      MyApp(name: 'Hoang',age: 18)//How to send arguments/params to this Widget ?
  );
}



