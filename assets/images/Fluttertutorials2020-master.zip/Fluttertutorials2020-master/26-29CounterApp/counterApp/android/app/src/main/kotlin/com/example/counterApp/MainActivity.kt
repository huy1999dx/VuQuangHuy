package com.example.counterApp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
