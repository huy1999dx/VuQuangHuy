enum CounterEvent {
  increment,
  decrement
}
//event => bloc