import 'package:flutter/material.dart';
import 'MyApp.dart';
void main(){
  //Center is a widget, Text is a widget
  runApp(MaterialApp(
    title: 'Transaction app',
    home: MyApp(),
  ));
}



